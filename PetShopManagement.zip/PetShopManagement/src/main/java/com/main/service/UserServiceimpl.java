package com.main.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.main.appexception.ApplicationException;
import com.main.dao.UserDao;
import com.main.model.Pet;
import com.main.model.User;

@Service("userServiceImpl")
public class UserServiceimpl implements UserService {

	@Autowired
	private UserDao userDaoImpl;
	
	@Transactional
	public void doesUserExists(User user) throws ApplicationException {
		userDaoImpl.doesUserExists(user);

	}

	@Transactional
	public void addUser(User user) {
		userDaoImpl.addUser(user);

	}

	@Transactional
	public void buyPet(long petId, User user) {
		userDaoImpl.buyPet(petId, user);

	}

	@Transactional
	public List<Pet> getMyPets(User user) {
		return (userDaoImpl.getMyPets(user));
	}
}
