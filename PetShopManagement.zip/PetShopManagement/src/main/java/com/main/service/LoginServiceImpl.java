package com.main.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.main.appexception.ApplicationException;
import com.main.dao.LoginDao;
import com.main.model.User;

@Service("loginServiceImpl")
public class LoginServiceImpl implements LoginService {

	@Autowired
	private LoginDao loginDaoImpl;

	@Transactional
	public User validateUser(User user) throws ApplicationException {
		return loginDaoImpl.validateUser(user);
	}
}
