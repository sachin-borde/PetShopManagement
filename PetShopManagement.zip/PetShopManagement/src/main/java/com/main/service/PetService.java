package com.main.service;

import java.util.List;

import com.main.model.Pet;

public interface PetService {

	public List<Pet> getAllPets();

	public void savePet(Pet pet);

}
