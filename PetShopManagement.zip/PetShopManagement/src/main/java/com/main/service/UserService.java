package com.main.service;

import java.util.List;

import com.main.appexception.ApplicationException;
import com.main.model.Pet;
import com.main.model.User;

public interface UserService {

	public void doesUserExists(User user) throws ApplicationException;

	public void addUser(User user);

	public void buyPet(long petId, User user);

	public List<Pet> getMyPets(User user);
	
}