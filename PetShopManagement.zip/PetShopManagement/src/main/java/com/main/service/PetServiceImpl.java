package com.main.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.main.dao.PetDao;
import com.main.model.Pet;

@Service("petServiceImpl")
public class PetServiceImpl implements PetService {

	@Autowired
	private PetDao petDaoImpl;

	@Transactional
	public List<Pet> getAllPets() {
		return petDaoImpl.getAllPets();
	}

	@Transactional
	public void savePet(Pet pet) {
		petDaoImpl.savePet(pet);
	}

}
