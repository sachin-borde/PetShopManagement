package com.main.dao;

import java.util.List;

import com.main.model.Pet;

public interface PetDao {

	public List<Pet> getAllPets();

	public void savePet(Pet pet);

}
