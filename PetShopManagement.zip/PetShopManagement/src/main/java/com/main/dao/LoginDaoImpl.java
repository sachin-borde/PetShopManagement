package com.main.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.main.appexception.ApplicationException;
import com.main.model.User;

@Repository("loginDaoImpl")
public class LoginDaoImpl implements LoginDao {

	@Autowired
	private SessionFactory sessionFactory;

	public User validateUser(User user) throws ApplicationException {

		Long userId;
		String sql = "SELECT userId  FROM User user WHERE user.userName=:userName AND user.password=:password";
		Session session = sessionFactory.getCurrentSession();
		Query query = session.createQuery(sql);
		query.setString("userName", user.getUserName());
		query.setString("password", user.getPassword());
		userId = (Long) query.uniqueResult();
		if (userId == null) {
			throw new ApplicationException("Either User Name or Password or both are invalid");
		} else {
			user.setUserId(userId);
		}
		return user;
	}

}
