package com.main.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.main.model.Pet;
import com.main.model.User;
import com.main.service.PetService;
import com.main.service.UserService;

@Controller
public class PetController {

	@Autowired
	private PetService petServiceImpl;

	@Autowired
	private UserService userServiceImpl;

	@RequestMapping("homepage")
	public String petHome(Model model, HttpServletRequest request) {
		User user = (User) request.getSession().getAttribute("user");
		if (user != null) {
			List<Pet> pets = petServiceImpl.getAllPets();
			if (pets.size() > 0) {
				model.addAttribute("pets", pets);
				return "homepage";
			} else {
				model.addAttribute("message", "THERE ARE NO PET IN LIST");
				return "homepage";
			}
		} else {
			return "redirect:user/login";
		}

	}

	@RequestMapping("addpet")
	public String addPetFront(Model model, HttpServletRequest request) {
		User user = (User) request.getSession().getAttribute("user");
		if (user != null) {
			model.addAttribute("petdetail", new Pet());
			return "addpet";
		} else {
			return "redirect:user/login";
		}

	}

	@PostMapping("added")
	public String addPet(@ModelAttribute("petdetail") Pet petdetails, Model model, HttpServletRequest request) {
		User user = (User) request.getSession().getAttribute("user");

		if (user != null) {
			try {
				petServiceImpl.savePet(petdetails);
				return "redirect:/homepage";
			} catch (Exception e) {
				model.addAttribute("error", e.getMessage());
				return "addpet";
			}
		} else {
			return "redirect:user/login";
		}

	}

	@RequestMapping("buypet/{petId}")
	public String buyPet(@PathVariable("petId") long petId, HttpServletRequest request) {
		User user = (User) request.getSession().getAttribute("user");

		if (user != null) {
			userServiceImpl.buyPet(petId, user);
			return "redirect:/mypet";
		} else {
			return "redirect:user/login";
		}
	}

	@RequestMapping("mypet")
	public String myPets(HttpServletRequest request, Model model) {
		User user = (User) request.getSession().getAttribute("user");

		if (user != null) {
			List<Pet> mypets = userServiceImpl.getMyPets(user);
			if (mypets.size() > 0) {
				model.addAttribute("mypets", mypets);
				return "mypet";
			} else {
				model.addAttribute("message", "YOUR PET LIST IS EMPTY");
				return "mypet";
			}
		} else {
			return "redirect:user/login";
		}
	}
}
