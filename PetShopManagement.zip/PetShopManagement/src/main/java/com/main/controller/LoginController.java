package com.main.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.main.appexception.ApplicationException;
import com.main.model.User;
import com.main.service.LoginService;

@Controller
@RequestMapping("user")
public class LoginController {

	@Autowired
	private LoginService loginServiceImpl;

	@RequestMapping("login")
	public String LoginUserFront(Model model) {
		model.addAttribute("logindetail", new User());
		return "login";
	}

	@PostMapping("logined")
	public String authenticateUser(@ModelAttribute("logindetail") User user, Model model, HttpServletRequest request) {
		try {
			User userObj = loginServiceImpl.validateUser(user);
			request.getSession().setAttribute("user", userObj);
			return "redirect:/homepage";
		} catch (ApplicationException e) {
			model.addAttribute("error", e.getMessage());
			return "login";
		}
	}
}
